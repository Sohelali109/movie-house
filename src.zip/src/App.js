import React from 'react'
import './App.css';
import './components/Movieapp.js';
import MovieApp from './components/Movieapp.js'

const App = () => {
  return (
    <div>
      <MovieApp></MovieApp>
    </div>
  )
}

export default App
